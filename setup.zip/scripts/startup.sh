#Set the keyboard layout to Danish
setxkbmap -option grp:alt_shift_toggle dk,dk

#Open VLC player
vlc --fullscreen --loop --no-qt-privacy-ask ~/Desktop/video.mp4